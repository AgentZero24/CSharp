namespace ViewModelFun.Models
{
    public class Users
    {
        public string FullName { get; set; }
    }
}