namespace ViewModelFun.Models
{
    public class Numbers
    {
        public int ListOfNumbers { get; set; }

    }
}