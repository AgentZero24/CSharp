namespace ViewModelFun.Models
{
    public class Message
    {
        public string FirstMessage { get; set; }
    }
}