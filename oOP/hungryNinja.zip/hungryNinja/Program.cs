﻿using System;

namespace hungryNinja
{
    class Program
    {
        static void Main(string[] args)
        {
            Buffet World = new Buffet();
            Ninja Paul = new Ninja();
            while(!Paul.IsFull)
            {
                Paul.Eat(World.Serve());
            }
        }
    }
}
